#Exercise
setwd("C:\\Users\\it24101836\\Desktop\\IT24101836")
data<-read.table("Exercise - LaptopsWeights.txt",header=TRUE)
fix(data)
attach(data)

#Question 1
weights <- read.table("Exercise - LaptopsWeights.txt", header = TRUE)
weights <- as.numeric(weights$Weight)
population_mean <- mean(weights)
population_sd <- sd(weights) * sqrt((length(weights) - 1) / length(weights))
cat("Population Mean:", population_mean, "\n")
cat("Population Standard Deviation:", population_sd, "\n")

#question 2
set.seed(123)
sample_size <- 6
num_samples <- 25
sample_means <- numeric(num_samples)
sample_sds <- numeric(num_samples)

for (i in 1:num_samples) {
  samp <- sample(weights, size = sample_size, replace = TRUE)
  sample_means[i] <- mean(samp)
  sample_sds[i] <- sd(samp)
  cat("Sample", i, "- Mean:", sample_means[i], 
      "SD:", sample_sds[i], "\n")
}
results <- data.frame(
  Sample = 1:num_samples,
  Mean = round(sample_means, 4),
  StdDev = round(sample_sds, 4)
)

print(results)

#Question 3

weights <- read.table("Exercise - LaptopsWeights.txt", header = TRUE)
weights <- as.numeric(weights$Weight)


pop_mean <- mean(weights)
pop_sd <- sd(weights) * sqrt((length(weights)-1)/length(weights))


set.seed(123)
num_samples <- 25
sample_size <- 6

sample_means <- numeric(num_samples)

for (i in 1:num_samples) {
  samp <- sample(weights, size = sample_size, replace = TRUE)
  sample_means[i] <- mean(samp)
}


mean_of_means <- mean(sample_means)
sd_of_means <- sd(sample_means)

theoretical_sd <- pop_sd / sqrt(sample_size)


cat("Population Mean:", pop_mean, "\n")
cat("Mean of Sample Means:", mean_of_means, "\n\n")

cat("Population SD:", pop_sd, "\n")
cat("SD of Sample Means:", sd_of_means, "\n")
cat("Theoretical SD (σ/√n):", theoretical_sd, "\n")


if (abs(mean_of_means - pop_mean) < 0.05) {
  cat("\nThe mean of the sample means is very close to the true mean, as expected.\n")
}
if (abs(sd_of_means - theoretical_sd) < 0.05) {
  cat("The SD of the sample means is close to the theoretical value σ/√n, as predicted by the Central Limit Theorem.\n")
}

